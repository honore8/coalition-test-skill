<?php $__env->startSection('title'); ?>
<?php echo e(__("Home")); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container" id="app">
    <h3 class="mt-3">CT - Laravel Test / Honoré Lata ( <a href="mailto:lkh@honore-lata.com">lkh@honore-lata.com</a> )</h3>

    <?php echo $__env->make('product.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <br>
    <div class="row">
        <div class="col-md-12">
            <form action="<?php echo e(route('edit.product', $product['count'])); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="card">
                    <div class="card-header">
                        <strong>Update a product</strong>
                    </div>
                    <div class="card-body">

                        <div class="mb-3">
                            <label for="product_name" class="form-label">Product Name:</label>
                            <input type="text" class="form-control" name="name" placeholder="Product Name" value="<?php echo e($product['name']); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="quantity" class="form-label">Quantity In Stock:</label>
                            <input type="number" class="form-control" name="quantity" placeholder="Quantity" value="<?php echo e($product['quantity']); ?>">
                        </div>

                        <div class="mb-3">
                            <label for="price" class="form-label">Price per Item:</label>
                            <input type="number" class="form-control" name="price" placeholder="Price per item" value="<?php echo e($product['price']); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary">Update Product</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
    <br>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /media/honore/82e96cf9-5e08-46a0-8f92-3dce4a19e5d6/home/honore/Documents/GitHub/coalition-test-skill/resources/views/product/edit.blade.php ENDPATH**/ ?>